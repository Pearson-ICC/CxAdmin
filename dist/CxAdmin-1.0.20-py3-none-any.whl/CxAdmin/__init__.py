from CxAdmin.objects.cx import Cx
from CxAdmin.objects.cxList import CxList
from CxAdmin.objects.cxQueue import CxQueue

Cx = Cx
CxList = CxList
CxQueue = CxQueue
